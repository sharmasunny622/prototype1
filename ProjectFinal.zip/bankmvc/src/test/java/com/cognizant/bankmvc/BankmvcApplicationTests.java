package com.cognizant.bankmvc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankmvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
