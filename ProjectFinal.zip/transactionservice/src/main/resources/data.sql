INSERT INTO TRANSACTION(id, source_Account_Id,source_Owner_Name,target_Account_Id,target_Owner_Name,amount,initiation_Date,reference)
VALUES (1, 10054546,'Sunny Kumar Sharma', 10054546, 'Sunny Kumar Sharma', 100.00, '2021-04-05 10:30', 'transfer');

